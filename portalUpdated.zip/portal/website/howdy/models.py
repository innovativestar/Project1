from django.db import models

# Create your models here.

class userGender (models.Model):
    Gender = models.CharField(max_length=50)



class userResponse (models.Model):
      PostResponse = models.CharField(max_length=200)