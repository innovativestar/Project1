 # howdy/views.py
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from .models import userGender, userResponse


# Create your views here.
class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'index.html', context=None)

# Add this view
#class StartPageView(TemplateView):
   # template_name = "start.html"

#class illnesspageView(TemplateView):
#        template_name = "illness.html"

class ResponseFileView(TemplateView):
        template_name = "ResponseFile.html"

class FinalMedicationView(TemplateView):
        template_name = "FinalMedication.html"

class OtherIllnessView(TemplateView):
        template_name="OtherIllness.html"

def StartPageView(request):
    if request.method=="POST":
        var1 = request.POST.get('message')
        if var1=='Male' or var1=='Female':

            #userGender.objects.create(Gender=(var1=='Male')) #boolean value return
            userGender.objects.create(Gender=var1)
            return redirect('illness.html')
            return IllnessPageView(request)

    return render(request,'start.html')

def IllnessPageView(request):
    if request.method=="POST":
        var2 = request.POST.get('message')
        userResponse.objects.create(PostResponse=var2)
        return redirect('ResponseFile.html')
    return render(request,'illness.html')