 # howdy/views.py
from django.shortcuts import render
from django.views.generic import TemplateView

# Create your views here.
class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request, 'index.html', context=None)

# Add this view
class StartPageView(TemplateView):
    template_name = "start.html"

class illnesspageView(TemplateView):
        template_name = "illness.html"

class ResponseFileView(TemplateView):
        template_name = "ResponseFile.html"

class FinalMedicationView(TemplateView):
        template_name = "FinalMedication.html"

class OtherIllnessView(TemplateView):
        template_name="OtherIllness.html"
