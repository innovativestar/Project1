#!/usr/bin/env python

print("Content-Type: text/html\n")


import cgi
import cgitb; cgitb.enable()  # for troubleshooting

print("Content-type: text/html")
print

print("""
<html>

<head><title>Illness</title></head>

<body>

  
""")

form = cgi.FieldStorage()
message = form.getvalue("message", "(no message)")

print("""

  <p>Previous message: %s</p>

  <h1>Using one or two words, please enter an disease you have had.</h1>
        
  <form method="post" action="illness.py">
    <p>Disease: <input type="text" name="message"/></p>
  </form>

</body>

</html>
""" % cgi.escape(message))
